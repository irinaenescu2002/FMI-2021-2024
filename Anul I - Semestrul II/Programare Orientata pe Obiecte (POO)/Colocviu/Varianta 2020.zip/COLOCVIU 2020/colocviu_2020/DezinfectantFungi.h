//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_DEZINFECTANTFUNGI_H
#define COLOCVIU_2020_DEZINFECTANTFUNGI_H

#include "Dezinfectant.h"

class DezinfectantFungi: public Dezinfectant {
public:
    long totalOrganisme() override;

    DezinfectantFungi(int mNrSpecii, const vector<string> &mIngrediente, const vector<string> &mTipSuprafata);

    int tip(){
        return 1;
    }
};


#endif //COLOCVIU_2020_DEZINFECTANTFUNGI_H
