//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_MASCA_H
#define COLOCVIU_2020_MASCA_H


class Masca {
public:
    /*
     * 1 => chirurgicala, 2=> policarbonat
     */
    virtual int tip() { return 0; }
    virtual double pret(){
        return 0;
    }
};


#endif //COLOCVIU_2020_MASCA_H
