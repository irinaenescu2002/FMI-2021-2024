//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_DEZINFECTANTBACTERII_H
#define COLOCVIU_2020_DEZINFECTANTBACTERII_H

#include "Dezinfectant.h"

class DezinfectantBacterii:public Dezinfectant {
public:
//    DezinfectantBacterii(const int mNrSpecii, const vector<string>mIngrediente, const vector<string>mTipSuprafata);

    DezinfectantBacterii(const int &mNrSpecii, const vector<string> &mIngrediente, const vector<string> &mTipSuprafata);

    long totalOrganisme() override;

    int tip(){
        return 1;
    }
};


#endif //COLOCVIU_2020_DEZINFECTANTBACTERII_H
