//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_DEZINFECTANTVIRUSURI_H
#define COLOCVIU_2020_DEZINFECTANTVIRUSURI_H

#include "Dezinfectant.h"

class DezinfectantVirusuri:public Dezinfectant {
public:
    long totalOrganisme() override;

    DezinfectantVirusuri(int mNrSpecii, const vector<string> &mIngrediente, const vector<string> &mTipSuprafata);

    int tip(){
        return 3;
    }
};


#endif //COLOCVIU_2020_DEZINFECTANTVIRUSURI_H
