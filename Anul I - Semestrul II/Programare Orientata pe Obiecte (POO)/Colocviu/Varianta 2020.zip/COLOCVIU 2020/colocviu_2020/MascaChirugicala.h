//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_MASCACHIRUGICALA_H
#define COLOCVIU_2020_MASCACHIRUGICALA_H

#include <iostream>
#include <string>
#include "Masca.h"

using namespace std;

class MascaChirugicala : public Masca {
public:
private:
    int tip() override {
        return 1;
    }

public:
    MascaChirugicala() : m_nrPliuri(0) {

    }

    MascaChirugicala(const string &mTipProtectie, const string &mCuloare, int mNrPliuri) : m_tipProtectie(
            mTipProtectie), m_culoare(mCuloare), m_nrPliuri(mNrPliuri) {}

    friend istream &operator>>(istream &in, MascaChirugicala &m) {
        cout << "Tip protectie: ";
        in >> m.m_tipProtectie;
        cout << "Culoare masca";
        in >> m.m_culoare;
        cout << "Numar pliuri: ";
        in >> m.m_nrPliuri;
        return in;
    }

    explicit operator string() const {
        return "Masca este de tip " + m_tipProtectie +
               " are culoarea " + m_culoare +
               " si are " + to_string(m_nrPliuri) + " pliuri";
    }

    friend ostream &operator<<(ostream &out, const MascaChirugicala &m) {
        out << (string) m;
        return out;
    }

    double pret() {

        if(m_tipProtectie == "ffp1") return 5;
        else if(m_tipProtectie == "ffp2") return 10;
        else return 15;
    }

private:
    string m_tipProtectie;
    string m_culoare;
    int m_nrPliuri;

};


#endif //COLOCVIU_2020_MASCACHIRUGICALA_H
