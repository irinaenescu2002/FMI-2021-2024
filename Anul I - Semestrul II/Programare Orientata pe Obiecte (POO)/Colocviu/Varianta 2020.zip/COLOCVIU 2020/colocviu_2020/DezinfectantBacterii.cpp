//
// Created by Alexandra on 13.05.2021.
//

#include "Dezinfectant.h"
#include "DezinfectantBacterii.h"

long DezinfectantBacterii::totalOrganisme() {
    return 1000000000;
}

DezinfectantBacterii::DezinfectantBacterii(const int &mNrSpecii, const vector<string>&mIngrediente, const vector<string>&mTipSuprafata):Dezinfectant(mNrSpecii, mIngrediente, mTipSuprafata) {}

