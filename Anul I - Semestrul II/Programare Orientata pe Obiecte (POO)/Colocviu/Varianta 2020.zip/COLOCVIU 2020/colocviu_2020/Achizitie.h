//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_ACHIZITIE_H
#define COLOCVIU_2020_ACHIZITIE_H

#include <string>
#include <vector>
#include "Dezinfectant.h"
#include "DezinfectantFungi.h"
#include "DezinfectantBacterii.h"
#include "DezinfectantVirusuri.h"
#include "Masca.h"
#include "MascaChirugicala.h"
#include "MascaPolicarbonat.h"
using namespace std;

class Achizitie {
public:
    Achizitie():m_zi(1),m_luna(1),m_an(2020) {

    }

    Achizitie(const int &mZi, const int &mLuna, const int &mAn, const string &mNumeClient){
        m_zi = mZi;
        m_an = mAn;
        m_luna = mLuna;
        m_numeClient.assign(mNumeClient);
    }
    Achizitie(const int &mZi, const int &mLuna, const int &mAn, const string &mNumeClient, const vector<Dezinfectant*> &mDezinfectanti, const vector<Masca*> &mMasti):m_dezinfectanti(mDezinfectanti), m_masti(mMasti){
        m_zi = mZi;
        m_an = mAn;
        m_luna = mLuna;
        m_numeClient.assign(mNumeClient);
    }
    Achizitie operator+=(Masca* m){
//        m_masti.push_back(new Masca(*m));
        if (m->tip() == 1) {
            m_masti.push_back(new MascaChirugicala(*dynamic_cast<MascaChirugicala*>(m)));
        } else if (m->tip() == 2) {
            m_masti.push_back(new MascaPolicarbonat(*dynamic_cast<MascaPolicarbonat*>(m)));
        }
        return *this;
        // vom avea nevoie sa stim ce tip de masca implementam
    }
    Achizitie operator+=(Masca& m){
        return *this += &m;
    }
    Achizitie(const Achizitie &a):Achizitie(a.m_zi,a.m_luna,a.m_an,a.m_numeClient,a.m_dezinfectanti,a.m_masti){
    }
    // operator=
    Achizitie operator=(const Achizitie &a){
        m_zi = a.m_zi;
        m_luna = a.m_luna;
        m_an = a.m_an;
        m_numeClient.assign(a.m_numeClient);
        m_dezinfectanti = a.m_dezinfectanti;
        m_masti = a.m_masti;
        return *this;
    }
    // destructor
    ~Achizitie(){
        for(auto *p : m_dezinfectanti)
        {
            delete p;
        }
        for(auto *p : m_masti)
        {
            delete p;
        }
    }

    Achizitie operator+=(const Dezinfectant &d){
        return *this+=&d;
    }
    Achizitie operator+=(const Dezinfectant *d){
        if (d->tip() == 1) {
            m_dezinfectanti.push_back(new DezinfectantBacterii(*dynamic_cast<const DezinfectantBacterii*>(d)));
        }else if(d->tip() == 2){
            m_dezinfectanti.push_back(new DezinfectantFungi(*dynamic_cast<const DezinfectantFungi*>(d)));
        }else if(d->tip() == 3){
            m_dezinfectanti.push_back(new DezinfectantVirusuri(*dynamic_cast<const DezinfectantVirusuri*>(d)));
        }
        return *this;
    }

    string nume(){
        return m_numeClient;
    }

    double pret() const{
        double pret = 0;
        for (auto *m : m_masti) {
            pret += m->pret();
        }
        for(auto *p:m_dezinfectanti){
            pret += p->pret();
        }
        return pret;
    }

    bool operator< (const Achizitie &dreapta) const{
        return pret() < dreapta.pret();
    }

    bool operator==(const Achizitie &dreapta) const{
        return pret() == dreapta.pret();
    }



private:
    int m_zi;
    int m_luna;
    int m_an;
    string m_numeClient;
    vector<Dezinfectant*> m_dezinfectanti;
    vector<Masca*> m_masti;
};


#endif //COLOCVIU_2020_ACHIZITIE_H
