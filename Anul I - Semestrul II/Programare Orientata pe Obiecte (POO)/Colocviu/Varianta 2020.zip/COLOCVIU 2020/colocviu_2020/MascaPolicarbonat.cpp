//
// Created by Alexandra on 13.05.2021.
//

#include "MascaPolicarbonat.h"


MascaPolicarbonat::MascaPolicarbonat() {

}

MascaPolicarbonat::MascaPolicarbonat(const string tipPrindere)  :m_tipPrindere(tipPrindere){

}

int MascaPolicarbonat::tip() {
    return 2;
}
