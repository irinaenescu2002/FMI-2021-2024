//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_MASCAPOLICARBONAT_H
#define COLOCVIU_2020_MASCAPOLICARBONAT_H

#include <iostream>
#include <string>
#include "Masca.h"

using namespace std;

class MascaPolicarbonat:public Masca {
private:

    string m_tipProtectie;
    string m_tipPrindere;
public:
    MascaPolicarbonat(const string tipPrindere);

private:
    int tip() override;

public:
    MascaPolicarbonat();

    friend istream &operator>>(istream &in, MascaPolicarbonat &m){
        cout<<"Tip protectie: ";
        in>>m.m_tipProtectie;
        cout<<"Culoare masca";
        in>>m.m_tipPrindere;
        return in;
    }
};


#endif //COLOCVIU_2020_MASCAPOLICARBONAT_H
