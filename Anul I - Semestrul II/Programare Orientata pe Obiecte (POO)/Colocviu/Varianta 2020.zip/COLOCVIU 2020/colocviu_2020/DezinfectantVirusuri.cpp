//
// Created by Alexandra on 13.05.2021.
//

#include "DezinfectantVirusuri.h"

long DezinfectantVirusuri::totalOrganisme() {
    return 100000000;
}

DezinfectantVirusuri::DezinfectantVirusuri(int mNrSpecii, const vector<string> &mIngrediente,
                                           const vector<string> &mTipSuprafata) : Dezinfectant(mNrSpecii, mIngrediente,
                                                                                               mTipSuprafata) {}
