//
// Created by Alexandra on 13.05.2021.
//

#include "DezinfectantFungi.h"

long DezinfectantFungi::totalOrganisme() {
    return 1,5 * 1000000;
}

DezinfectantFungi::DezinfectantFungi(int mNrSpecii, const vector<string> &mIngrediente,
                                     const vector<string> &mTipSuprafata) : Dezinfectant(mNrSpecii, mIngrediente,
                                                                                         mTipSuprafata) {}
