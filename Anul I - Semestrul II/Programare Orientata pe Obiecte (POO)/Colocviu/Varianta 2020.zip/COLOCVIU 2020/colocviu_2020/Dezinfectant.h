//
// Created by Alexandra on 13.05.2021.
//

#ifndef COLOCVIU_2020_DEZINFECTANT_H
#define COLOCVIU_2020_DEZINFECTANT_H

#include <vector>
#include <string>

using namespace std;

class Dezinfectant {
protected:
    int m_nrSpecii;
    vector<string> m_ingrediente;
    vector<string> m_tipSuprafata;
public:
    Dezinfectant(int mNrSpecii, const vector<string> &mIngrediente, const vector<string> &mTipSuprafata) : m_nrSpecii(
            mNrSpecii), m_ingrediente(mIngrediente), m_tipSuprafata(mTipSuprafata) {}

    virtual long totalOrganisme() { return 0; }

    float eficienta() {
        return m_nrSpecii / totalOrganisme();
    }
public:
    /*
     * 1 => Bacterii
     * 2 => Fungi
     * 3 => Virusuri
     */
    virtual int tip() const {
        return 0;
    }
    virtual double pret(){
        if(this->eficienta() < 90) return 10;
        else if(this->eficienta() < 95) return 20;
        else if(this->eficienta() < 97.5) return 30;
        else if(this->eficienta() < 99) return 40;
        else return 50;
    }
};


#endif //COLOCVIU_2020_DEZINFECTANT_H
